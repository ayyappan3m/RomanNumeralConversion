package com.example.romannumeral;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.romannumeral.exception.InvalidQueryException;

@RestController
@CrossOrigin(origins = "http://localhost:3000")  // Allow requests from the React app on localhost:3000
public class RomanNumeralController {

    private final RomanNumeralConverter romanNumeralConverter;

    public RomanNumeralController(RomanNumeralConverter romanNumeralConverter) {
        this.romanNumeralConverter = romanNumeralConverter;
    }

    @GetMapping("/romannumeral")
    public ResponseEntity<RomanNumeralResponse> convertToRoman(@RequestParam(value = "query", required = false) String query) {
        if (query == null || query.trim().isEmpty()) {
            throw new InvalidQueryException("Query parameter 'query' is required.");
        }

        try {
            int input = Integer.parseInt(query);  // Parse the query as an integer
            if (input <= 0 || input > 3999) {
                throw new InvalidQueryException("Query parameter 'query' must be between 1 and 3999.");
            }

            String roman = romanNumeralConverter.toRoman(input);
            return ResponseEntity.ok(new RomanNumeralResponse(query, roman));

        } catch (NumberFormatException e) {
            throw new InvalidQueryException("Query parameter 'query' must be a valid integer.");
        }
    }
}


