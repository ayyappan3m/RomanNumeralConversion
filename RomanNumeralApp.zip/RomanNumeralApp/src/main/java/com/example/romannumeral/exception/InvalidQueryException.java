package com.example.romannumeral.exception;

public class InvalidQueryException extends RuntimeException{
	private static final long serialVersionUID = 1L;  // Adding serialVersionUID to fix the warning
	public InvalidQueryException(String message) {
        super(message);
    }
}
