package com.example.romannumeral.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.romannumeral.RomanNumeralResponse;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(InvalidQueryException.class)
    public ResponseEntity<RomanNumeralResponse> handleInvalidQuery(InvalidQueryException ex) {
        // Return a custom error message with a 400 BAD REQUEST status
        RomanNumeralResponse errorResponse = new RomanNumeralResponse("Invalid Query", ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);  // 400 Bad Request
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<RomanNumeralResponse> handleGeneralException(Exception ex) {
        // Return a custom error message for any unexpected exceptions
        RomanNumeralResponse errorResponse = new RomanNumeralResponse("Internal Error", "An unexpected error occurred.");
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);  // 500 Internal Server Error
    }
}
