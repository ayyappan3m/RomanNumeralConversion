package com.example.demo;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.mockito.InjectMocks;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import com.example.romannumeral.RomanNumeralApplication;
import com.example.romannumeral.RomanNumeralController;
import com.example.romannumeral.RomanNumeralConverter;

@SpringBootTest(classes = RomanNumeralApplication.class)  // Use your main application class here
@AutoConfigureMockMvc
public class RomanNumeralControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private RomanNumeralConverter romanNumeralConverter;

    @InjectMocks
    private RomanNumeralController romanNumeralController;

    @Test
    public void testConvertToRoman() throws Exception {
        // Mocking the behavior of the RomanNumeralConverter
        given(romanNumeralConverter.toRoman(2025)).willReturn("MMXXV");

        // Test the actual controller behavior
        mockMvc.perform(get("/romannumeral?query=2025"))
                .andExpect(status().isOk())  // HTTP 200 response
                .andExpect(jsonPath("$.input").value("2025"))  // Check input field in response
                .andExpect(jsonPath("$.output").value("MMXXV"));  // Check expected Roman numeral output
    }
}