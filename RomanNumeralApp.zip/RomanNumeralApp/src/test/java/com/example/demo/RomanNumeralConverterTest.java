package com.example.demo;


import org.junit.jupiter.api.Test;

import com.example.romannumeral.RomanNumeralConverter;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class RomanNumeralConverterTest {

    RomanNumeralConverter converter = new RomanNumeralConverter();

    @Test
    public void testToRoman() {
        // Test cases for different numbers
        assertEquals("I", converter.toRoman(1));
        assertEquals("V", converter.toRoman(5));
        assertEquals("X", converter.toRoman(10));
        assertEquals("XIV", converter.toRoman(14));
        assertEquals("XXI", converter.toRoman(21));
        assertEquals("MMMCMXCIX", converter.toRoman(3999));
    }
}

