package com.example.demo;  // Updated to the new package


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.romannumeral.RomanNumeralApplication; // Import the main application class

@SpringBootTest(classes = RomanNumeralApplication.class)  // Explicitly specify the application class
class RomanNumeralAppApplicationTests {

    @Test
    void contextLoads() {
    }
}
